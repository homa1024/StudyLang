x = 3
sumi i n f
     | i <= n = f i + sumi (i+1) n f
     | otherwise = 0

f16i x n = sin (n*x) / n * ((-1) ^ (floor (n-1)))
f16 x n = 2 * sumi 1 n (f16i x)

f17i x n = ((-1) ^ (floor n)) / (n ^ 2) * cos (n * x)
f17 x n = pi ^ 2 / 3.0 + 4 * sumi 1 n (f17i x)

f18i x n = sin ((2*n - 1)*pi*x) / (2*n - 1)
f18 k x n = (4*k/pi) * sumi 1 n (f18i x)

f19i x n = cos ((2*n - 1) * pi * x / 2) / ((2*n -1 )^2)
f19 n x = 1 - (8 / (pi^2)) * sumi 1 n (f19i x)

f20i x n = cos ((2*n - 1) * pi * x / 4) / ((2*n-1)^2)
f20 n x = 2 + (16 / (pi^2)) * sumi 1 n (f20i x)

f21i x n = sin ((2*n-1)*pi*x) / (2*n-1)
f21 n x = (1/2) - (2/pi) * sumi 1 n (f21i x)

f34i n = 1/(n^4)
f34 n = (8/45)*(pi^5) - 16*pi*sumi 1 n f34i

f34l n = (8/45)*(pi^5) - 16*pi*sumi 1 n (\n -> 1/n^4)


