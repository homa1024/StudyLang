import Graphics.UI.GLUT

main = do
  initialDisplayMode $= [ DoubleBuffered, RGBMode]
  initialWindowSize $= Size 500 500
    
  createWindow "Hello Window"
    
  displayCallback $= my_display
    
  mainLoop
    
my_display :: IO ()
my_display = do
  clear [ColorBuffer]

  --表示
  preservingMatrix $ do
    color (Color3 1.0 1.0 0.0 :: Color3 Double)     -- 色を変更。
    renderPrimitive Polygon $ mapM_ vertex          -- 四角形を描画。
      [   Vertex3 0.2    0.2    0.0 ,
          Vertex3 (-0.2) 0.2    0.0 ,
          Vertex3 (-0.2) (-0.2) 0.0 ,
          Vertex3 0.2    (-0.2) 0.0 :: Vertex3 GLdouble]
    renderPrimitive LineLoop $ mapM_ vertex         -- 四角形を描画。
      [   Vertex3 0.3    0.0    0.0 ,
          Vertex3 0.0    0.3    0.0 ,
          Vertex3 (-0.3) 0.0    0.0 ,
          Vertex3 0.0    (-0.3) 0.0 :: Vertex3 GLdouble]
    swapBuffers