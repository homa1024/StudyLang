-- �֐��Ղ낮��݂񂮓���
-- 1.1
square :: Integer -> Integer
square x = x * x

smaller :: (Integer, Integer) -> Integer
smaller (x,y) = if x <= y then x else y

quad :: Integer -> Integer
quad x = square (square x)

greater :: (Integer, Integer) -> Integer
greater (x,y) = if x >= y then x else y

-- 1.2
three :: Integer -> Integer
three x = 3

infinity :: Integer
infinity = infinity + 1

-- 1.3
multiply :: (Integer, Integer) -> Integer
multiply (x,y) = if x == 0 then 0 else x * y

-- 1.4
double, double' :: Integer -> Integer
double x = x + x;
double' x = 2 * x;

smallerc :: Integer -> (Integer -> Integer)
smallerc x y = if x <= y then x else y

twice :: (Integer -> Integer) -> (Integer -> Integer)
twice f x = f (f x)

quad', quad2 :: Integer -> Integer
quad' = twice square
quad2 = square . square

f :: Integer -> Integer
f x = x + 1
g :: Integer -> (Integer -> Integer)
g x y = x + y


--h:: Integer -> Integer -> Integer
--h = f . g

h' :: Integer -> Integer -> Integer
h' x = f . (g x)

h'' :: Integer -> Integer -> Integer
h'' x y = f (g x y)

delta :: (Float, Float, Float) -> Float
delta (a,b,c) = sqrt (b * b - 4 * a * c)

deltac :: Float -> Float -> Float -> Float
deltac a b c =  sqrt (b * b - 4 * a * c)

-- mylog :: Float -> Float -> Float

-- 1.5
fact :: Integer -> Integer
fact n
     | n < 0 = error "negative argument to fact"
     | n == 0 = 1
     | n > 0 = n * fact (n-1)

fff :: Integer -> Integer -> Integer
fff x y
    | x <= 10 = x + a
    | x > 10 = x - a
    where a = square (y + 1)

fib :: Integer -> Integer
fib x
    | x == 0 = 0
    | x == 1 = 1
    | otherwise = fib (x-1) + fib (x-2)

myabs :: Integer -> Integer
myabs x = sign * x
    where sign = signum x

-- 1.6
subst :: (t0 -> t1 -> t2) -> (t0 -> t1) -> t0 -> t2
subst f g x = f x (g x)

apply :: (t0 -> t1) -> t0 -> t1
apply f x = f x

f1_6 :: (Integer,Integer) -> Integer
f1_6 (x,y) = x - y

swap ::  (b,a) -> (a,b)
swap (x,y) = (y,x)

strange :: ((a -> b) -> a) -> (a -> b) -> b
strange f g = g (f g)

-- cannot assign type to f in stranger
-- stranger f = f f