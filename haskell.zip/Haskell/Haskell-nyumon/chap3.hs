import Debug.Trace

(#) :: (a -> b) -> (b -> c) -> (a -> c)
f # g = g . f
infixl 2 #

(#>) :: a -> (a -> b) -> b
x #> f = f x
infixl 1 #>

ptap x = trace (show x) x

-- Chap3 数値
-- 3.1 自然数 -- !#$%&*+_/<=>?@\^-~
data Nat = Zero | Succ Nat
         deriving (Show)
instance Eq Nat where
  Zero == Zero = True
  Zero == Succ n = False
  Succ m == Zero = False
  Succ m == Succ n = m == n
  
addN :: Nat -> Nat -> Nat
m `addN` Zero = m
m `addN` Succ n = Succ (m `addN` n)

infinity :: Nat
infinity = Succ infinity

convert :: Nat -> Integer
convert Zero = 0
convert (Succ n) = 1 + convert n

-- 3.3 畳み込み関数
foldn h c Zero = c
foldn h c (Succ n) = trace (show n ++ ", " ++ show recret) (h recret)
  where
    recret = foldn h c n

mulN m n = foldn (`addN` m) Zero n

fact :: Nat -> Nat
fact = snd. foldn f (Zero, Succ Zero)
       where f (m, n) = (Succ m, Succ m `mulN` n)

convert2 = foldn (\x -> x + 1) 0
-- fact (Succ(Succ(Succ Zero)))
-- = snd. foldn f (Zero, Succ Zero) (Succ(Succ(Succ Zero)))
-- = snd (foldn f (Zero, Succ Zero) (Succ(Succ(Succ Zero))))
-- = snd (f( foldn f (Zero, Succ Zero) (Succ(Succ Zero))))
-- = snd (f(f(foldn f (Zero, Succ Zero) (Succ Zero))))
-- = snd (f(f(f(foldn f (Zero, Succ Zero) Zero))))
-- = snd (f(f(f((Zero,Succ Zero)))))
-- = snd (f(f(1,1)))
-- = snd (f(2,2))
-- = snd (3,6)
-- = 6

fib 0 = 0
fib 1 = 1
fib n = fib (n-1) + fib (n-2)

-- 3.4 Haskell の数値
-- class (Eq a, Show a) => Num a  比較できて、表示できる。 + - * 出来る
-- class (Num a) => Fractional a  割り算が出来る
-- instance Fractional Float

-- class (Num a, Ord a) => Real a     大小比較できる
-- class (Real a, Enum a) => Integral 番号付できる
-- instance Integral Integer

-- 3.5 例：有理数
-- 略

-- 3.6 例：線形探索と２分探索
-- 関数floor仕様
-- floor :: Float -> Integer
-- (floor x) = n === n <= x < n + 1
mUntil :: (a -> Bool) -> (a -> a) -> a -> a
mUntil p f x = if p x then x else mUntil p f (f x)

mFloor x = searchFrom 0
  where
    searchFrom = lower
                 # ptap
                 # upper
                 # ptap
                 # decrease
    lower = mUntil ((<= x) . fromIntegral) decrease -- <= の比較で引数はxと同じでないといけない よって返り値が Doubleとかになる。それを防ぐため、 fromIntegralで返り値の型を守る
    upper = mUntil ((> x) . fromIntegral) increase
    increase n = n + 1
    decrease n = n - 1

{- mFloor C言語 ver
int mFloor(int x) {
  int n = 0
  while (!(n <= x)) {
    n--
  }
  while (!(n > x)) {
    n++ 
  }
  n--
  return n
}
-}
cross (f, g) (x, y) = (f x, g y)
mFloor2 x = serchFrom (-1, 1)
            where
              serchFrom = cross (lower, upper)
                          # ptap
                          # middle
                          # fst
              lower = mUntil ((<= x) . fromIntegral) (* 2)
              upper = mUntil ((> x) . fromIntegral) (* 2)
              middle = mUntil done improve
              done (m, n) = (m + 1 == n)
              improve (m, n)
                | fromIntegral p <= x =  ptap (p, n)
                | fromIntegral p > x = ptap (m, p)
                where p =  ((m + n) `div` 2)

-- 3.7 チャーチ数
-- チャーチ論理                      
type Cbool a = (a -> a -> a)

true, false :: a -> a -> a
true x y = x
false x y = y

mNot :: Cbool (Cbool a) -> Cbool a
mNot x = x false true

mAnd, mOr :: Cbool (Cbool a) -> Cbool a -> Cbool a
mAnd x y  = x y false
mOr x y = x true y

-- チャーチ数
type Cnum a = (a -> a) -> (a -> a)

zero, one, two :: Cnum a
zero = \f -> id
one = \f -> f
two = \f -> f . f
mSucc :: Cnum a -> Cnum a
mSucc cn = \f -> f . cn f

-- 章末 3.7.1
isZero :: Cnum a -> Cbool a
-- isZero :: ((a -> a) -> (a -> a)) -> a -> a -> a
isZero cn x y = (cn (\x -> y)) x

