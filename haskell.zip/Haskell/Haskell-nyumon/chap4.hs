import Debug.Trace

(#) :: (a -> b) -> (b -> c) -> (a -> c)
f # g = g . f
infixl 2 #

(#>) :: a -> (a -> b) -> b
x #> f = f x
infixl 1 #>

ptap x = trace (show x) x

-- Chap4 リスト