-- $ 2.6.1
-- <'type' ver> cannnot use type synonym in instance head
-- type Distance = Float
-- distEq :: Distance -> Distance -> Bool
-- distEq a b = dif < 10
--              where
--                dif = abs (a - b)
-- instance Eq Distance where
--   (==) = distEq

-- <'data' Ver> OK
data Distance = MkDist Float
                deriving (Show)
instance Eq Distance where
  MkDist x == MkDist y = dif < 10
                         where
                           dif = abs (x - y)
bottomChk :: Distance -> Bool
bottomChk (MkDist _) = True
bottomChk _ = False
-- -- result --
-- Main> bottomChk undefined
-- True
-- Main> bottomChk undefined
-- Program error: Prelude.undefined

-- -- <'newtype' Ver>
-- newtype Distance = MkDist Float
--                    deriving (Show)
-- instance Eq Distance where
--   MkDist x == MkDist y = dif < 10
--                          where
--                            dif = abs (x - y)
-- bottomChk :: Distance -> Bool
-- bottomChk (MkDist _) = True
-- bottomChk _ = False
-- -- --result--
-- -- Main> bottomChk (MkDist 3)
-- -- True
-- -- Main> bottomChk undefined
-- -- True


-- $ 2.6.2
data Jane = MkJane Int
            deriving (Show)
newtype Dick = MkDick Int
               deriving (Show)
matchJane :: Jane -> Bool
matchJane (MkJane _) = True
matchJane _ = False
              
matchDick :: Dick -> Bool
matchDick (MkDick _) = True 
matchDick _ = False

main262 = do
  print $ matchDick undefined
  print $ matchJane undefined

{-- memo
matchDick (MkDick _) = True 
において型Dickはnewtypeされたものだから
コンパイル時にMkDickは取り除かれて
matchDick _ = True
と等価の動きをする。 --}

-- $ 2.7
荻原