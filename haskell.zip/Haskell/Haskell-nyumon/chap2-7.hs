{-- 関数プログラミング入門
2.7章 文字列
--}
import Data.List


(#) :: (a -> b) -> (b -> c) -> (a -> c)
f # g = g . f
infixl 2 #

(#>) :: a -> (a -> b) -> b
x #> f = f x
infixl 1 #>
 
myFoldl :: (a -> a -> a) -> [a] -> a
myFoldl f (x:xs) = foldl f x xs
-- 2.7.1
strs = ["McMillan", "Macmillan", "MacMillan"]
main = do
  let sortStr = sort strs
  print sortStr
  print $ sortStr #> myFoldl catStr
  print $ sortStr #> foldr catStr "@"
  where
    catStr s1 s2 = s1 ++ " " ++ s2
                            
-- 2.7.3
data Month = Dam | Jan | Feb | Mar | Spr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec
           deriving (Enum, Show)

showDate (day, mon, year) = show day ++ show (toEnum mon :: Month) ++ show year