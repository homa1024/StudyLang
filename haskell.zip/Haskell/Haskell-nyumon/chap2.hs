--
import Data.Char

data MyBool = MyFalse | MyTrue
     deriving Show
-- instance Show MyBool where
--          show MyTrue = "MyTrue"
--          show MyFalse = "MyFalse"

mynot :: MyBool -> MyBool
mynot MyFalse = MyTrue
mynot MyTrue  = MyFalse

-- !#$%&*+_/<=>?@\^-~
data Triangle = Failure | Isosceles | Equilateral | Scalene
     deriving Show
analyse :: (Int, Int, Int) -> Triangle
analyse (x,y,z)
        | x + y <= z = Failure
        | x == z = Equilateral
        | and [(x == y), (y == z)] = Isosceles
        | otherwise = Scalene

(&), (!) :: Bool -> Bool -> Bool
True & True = True
_ & _ = False

False ! False = False
_ ! _ = True

(==>) :: Bool -> Bool -> Bool
True ==> False = False
_ ==> _ = True

class MyEq a where
      (==#), (/=#) :: a -> a -> Bool
      x /=# y = not (x ==# y)
data MyData = Foo | Bar
     deriving (Show, Eq)
instance MyEq MyData where
         x ==# y = x == y

-- 2.2
nextlet :: Char -> Char
nextlet c = chrA (mod (ordA c + 1) (ordA 'Z' + 1))
        where
        chrA n = chr (n + ord 'A')
        ordA c = ord c - ord 'A'

digitval :: Char -> Int
digitval n
         | (n < '0') || ('9' < n) = error "input charctor is not digit"
         | otherwise = ord n - ord '0'

-- 2.3
class (MyEq a) => MyOrd a where
      (<#), (<=#), (>=#), (>#) :: a -> a -> Bool
      x <=# y = (x <# y) || (x ==# y)
      x >=# y = (x ># y) || (x ==# y)
      x ># y = not (x <=# y)

class Enum2 a where
      fromEnum2 :: a -> Int
      toEnum2 :: Int -> a
data Day = Sun | Mon | Tue | Wed | Thu | Fri | Sat
     deriving Show
-- warning : toEnum2 ha toEnum2 0 :: Day no youni tukau
instance Enum2 Day where
         fromEnum2 Sun = 0 
         fromEnum2 Mon = 1 
         fromEnum2 Tue = 2 
         fromEnum2 Wed = 3 
         fromEnum2 Thu = 4 
         fromEnum2 Fri = 5 
         fromEnum2 Sat = 6
         toEnum2 n
                 | 0 == n = Sun            
                 | 1 == n = Mon            
                 | 2 == n = Tue            
                 | 3 == n = Wed            
                 | 4 == n = Thu            
                 | 5 == n = Fri            
                 | 6 == n = Sat            
                 | otherwise = error "error"         
instance MyEq Day where
         x ==# y = fromEnum2 x == fromEnum2 y
instance MyOrd Day where
         x <# y = fromEnum2 x < fromEnum2 y

workday :: Day -> Bool
workday d = (Mon <=# d) && (d <=# Fri)
         
data Day2 = Sun2 | Mon2 | Tue2 | Wed2 | Thu2 | Fri2 | Sat2
     deriving (Eq, Ord, Enum)

dayAfter :: Day -> Day
dayAfter d = toEnum2 ((fromEnum2 d + 1) `mod` 7)
dayBefore :: Day -> Day
dayBefore d = toEnum2 ((fromEnum2 d + 6) `mod` 7)

data Direction = North | East | South | West
     deriving (Show, Eq, Enum)
dirReverse :: Direction -> Direction
dirReverse d = toEnum((fromEnum d + 2) `mod` 4)

-- 2.4
data Pair a b = MkPair a b
     deriving (Show)

pair :: (a -> b, a -> c) -> a ->  (b, c)
pair (f,g) x = (f x, g x)
-- ex. pair (dayAfter, fromEnum2) Sun

cross :: (a -> b, c -> d) -> (a, c) -> (b, d)
cross (f, g) = pair (f . fst, g . snd)

crossEx = cross ((+2), dayAfter)
-- ex pair (dayAfter, fromEnum2) Sun
-- ex crossEx (3,Sun)

cross' :: (a -> b, c -> d) -> (a, c) -> (b, d)
cross' (f, g) (x, y) = (f x, g y)

pifun :: () -> Float
pifun () = 3.14159

-- instance (Eq a, Eq b) => Eq (a, b) where
--          (x,y) == (u,v) = (x == u) && (y == v)


yearsOld, yearsOld' :: (Integer, Integer, Integer) -> (Integer, Integer, Integer) -> Integer
yearsOld (d, m, y) (bd, bm, by)
         | m < bm || (m == bm && d < bd)= years - 1
         | otherwise = years
         where
                years = y - by

yearsOld' (d, m, y) (bd, bm, by)
         | day < bday = years -1
         | otherwise = years
         where
                day = (m, d)
                bday = (bm, bd)
                years = y - by

-- 2.5
data Either' a b = Left' a | Right' b
     deriving (Show)

case' :: (a -> c, b -> c) -> Either' a b -> c
case' (f, g) (Left' x) = f x
case' (f, g) (Right' y) = g y

plus :: (a -> c, b -> d) -> Either' a b -> Either' c d
plus (f, g) = case' (Left' . f, Right' . g)
-- ex. plus ((+2), ord) (Left' 3)
-- ex. plus ((+2), ord) (Right' 'a')

-- �ؖ� case (f,g) . plus (h, k) = case (f.h, g.k)
-- (����)
-- = case (f,g) . case (Left.h, Right.k)
-- = case (case (f,g) . Left . h, case (f,g) . Right . k)
-- = case (f.h, g.k)
-- = (�E��)

-- ��v�f(bottom) �� undefined �Ƃ������O�̕ϐ��œ��͂ł���

plus' :: (a -> c, b -> d) -> Either' a b -> Either' c d
plus' (f, g) (Left' x) =  Left' (f x)
plus' (f, g) (Right' y) = Right' (g y)

hoge :: Either' a b -> Integer
hoge (Left' _) = 0
hoge (Right' _) = 1
hoge (_) = 2

-- 2.6
-- type Coeffs = (Float, Float, Float)
-- type Roots = (Float, Float)
-- roots :: Coeffs -> Roots

type Position = (Float, Float)
type Angle = Float
type Distance = Float
move :: Distance -> Angle -> Position -> Position
move d a (x,y) = (x + d * cos a, y + d * sin a)

type Pairs a = (a, a)
type Automorph a = a -> a
type Flag a = (a, Bool)

newtype Angle' = MkAngle Float
        deriving (Show)