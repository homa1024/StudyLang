import Data.List


ss = subsequences
uniq [] = []
uniq [x] = [x]
uniq (x1:x2:xs) 
     | x1 == x2 = uniq (x2:xs)
     | otherwise = x1 : uniq (x2:xs)