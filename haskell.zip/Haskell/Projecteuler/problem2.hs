 fib = 1 : 2 : zipWith (+) fib (tail fib)
fib400 = takeWhile (< 4000000) fib
fib400Ev = filter even fib400
ret = sum fib400Ev
main = print ret