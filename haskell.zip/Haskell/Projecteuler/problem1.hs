mult3 = cycle [0,0,1]
mult5 = cycle [0,0,0,0,1]
or2 x y 
    | 0 == x + y = 0
    | otherwise = 1
mult3or5 = zipWith or2 mult3 mult5
ret = sum $ zipWith (*) [1..999] mult3or5

main = print ret