range = [1..100]
sumOfSq = sum $ map (^2) range
sqOfSum = (^2) $ sum range

main = print $ sqOfSum - sumOfSq