import Data.List
import MyUtil (factorize)

setDupIndex ns = genDupIndex 1 ns
    where
      genDupIndex _ [] = []
      genDupIndex i [n] = [(i,n)]
      genDupIndex i (n1:n2:ns) = genDupIndex i2 (n2:ns)
          where
            i2 | n1 == n2 = (i+1)
               | otherwise = 1

ret = foldl (*) 1 $ map snd $ foldl union [] (map setDupIndex (map factorize [1..20]))

main = print ret
