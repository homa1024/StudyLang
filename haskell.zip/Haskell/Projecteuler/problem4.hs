import Data.Char
import Data.List

range = [100..999]
all3mul3 = sortBy (flip compare) [x*y | x <- range, y <- range]

splitNum :: Int -> String
splitNum 0 = []
splitNum n = (intToDigit m) : splitNum d
    where
      (d,m) = divMod n 10
isPalindrome :: String -> Bool
isPalindrome str = str == reverse str

main = print $ head $ filter (isPalindrome) (map splitNum all3mul3)

