int2Double :: Integral a => a -> Double
int2Double = fromRational.toRational

isPrime :: Integral a => a -> Bool
isPrime n = length ([x | x <- [1..m], n `mod` x == 0]) == 1
            where m = round $ sqrt (int2Double n)
primes n = [x | x <- [2..n], isPrime x]

isFactor n a = n `mod` a == 0

factorize n = genFactor n (primes n)
    where 
      genFactor m ps
            | m == 1 = []
            | otherwise = a : genFactor m2 (a:ps2)
          where
            (a:ps2) = dropWhile (not.(isFactor m)) $ ps
            m2 = m `div` a

main = print $ last $ factorize 600851475143