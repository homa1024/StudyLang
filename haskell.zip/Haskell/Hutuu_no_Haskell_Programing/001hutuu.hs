import Data.List


-- 指定文字までtake
takefor c [] = []
takefor c (x:xs)
  | c == x = []
  | otherwise = x : takefor c xs
                
-- (a,b) |-> a とか射影ってどっかでみたっ!
project1 = fst
project2 = snd

--------------------------------
-- cat -n のように標準入力に行番号をつけて表示
--
numbering :: String -> String
numbering cs = unlines $ map format $ zipLineNumber $ lines cs

zipLineNumber :: [String] -> [(Int, String)]
zipLineNumber xs = zip [1..] xs

format :: (Int, String) -> String
format (n, line) = rjust 6 (show n) ++ " " ++ line

rjust :: Int -> String -> String
rjust width s = replicate (width - length s) ' ' ++ s
  

----------------------------------------
-- パターンマッチ
--
-- いっきには出来なかった
func1 [x] [y] = (x,y) -- リストパターン
func2 (x:xs) (y:ys) = (x,y) -- データコンストラクタによるパターン
func3 (a,b) _ = (a,b) -- タプルパターン _パターン
func4 3 11 = (777,777) -- リテラルパターン
func5 "s" "t" = ("homa","t") -- リテラルパターン
func6 x y = (x,y) -- 変数パターン
func7 str@(c:cs) = (str, c, cs) -- アズパターン
funcAsAs str@(c:(str2@(c2:ccs))) = (str, str2, c, c2, ccs)
asas c@c2@c3@c4 = (c,c2,c3,c4)


----------------------------------------
-- パターンマッチをする多相関数
-- マッチするにはEqが必要
-- マッチに使うリテラルのもつクラスも必要
func :: (Eq a, Eq b, Num a, Num b) => a -> b -> (a,b)
func 3 11 = (777, 777)
func x y = (x,y)
           

----------------------------------------
-- 代数的データ型

-- 構造体的スタイル   
--    例 htmlアンカー
data Anchor = A String String
compileAnchor :: Anchor -> (String, String)
compileAnchor (A url label) = (url, label) -- データコンストラクタによるパターン

-- フィールドラベル
data Anchor2 = A2 { aUrl :: String,
                    aLabel :: String }
anc1 = A2 {aUrl = "http://..", aLabel = "link"} -- 値の書き方
       
compileAnchor2 :: Anchor2 -> (String, String)
compileAnchor2 (A2 {aUrl = "http", aLabel = "label"}) = ("this is", "default") -- パターンマッチもフィールドラベル使って出来る
compileAnchor2 anc = (aUrl anc, aLabel anc) -- フィールドラベルをつけると同じ名前のセレクタ関数が自動定義される

-- フィールドの一部を変えた値の作成
label2not :: Anchor2 -> Anchor2
label2not anc = anc {aLabel = "not"} -- ancのaLabelフィールドを"not"に変えたAnchor2型の値を作る

-- 列挙型スタイル
--   例 ファイルオープンモード
data OpenMode = ReadOnly | WriteOnly | ReadWrite
              deriving (Show)

-- 共用体スタイル
--   例 IntとStringを共用
data PTItem = Param Int | Text String
pItem = Param 10
tItem = Text "hogee"

printPTItem :: PTItem -> String
printPTItem (Param x) = show x
printPTItem (Text str) = str


-- 再帰的な型
--   例 stack
data Stack a = Empty | Push a (Stack a)
             deriving (Show)
stk = Push 0 (Push 1 (Push 2 Empty))

isEmpty :: Stack a -> Bool
isEmpty Empty = True
isEmpty (Push _ _) = False

top :: Stack a -> a
top (Push x _) = x
pop :: Stack a -> Stack a
pop (Push _ stk) = stk

----------------------------------------
-- 9.6 練習問題

-- 1. 2. 3. 4.
data Line = Line {number :: Int,
                  string :: String }
            deriving (Show)
-- 5.
instance Eq Line where
    (==) (Line {number = x}) (Line {number = y}) = x == y
instance Ord Line where
    compare (Line {number = x}) (Line {number = y})
        | x == y = EQ
        | x < y = LT
        | otherwise = GT
    
sortLines :: [Line] -> [Line]
sortLines ls = sortBy compare ls
mylines = [Line 3 "three", Line 0 "zero", Line 5 "five", Line 10 "ten"]

-- メモ
-- type はただの型名のalias. その上の関数定義も同じものが使われる
-- newtype は型が表す値の集合としては同じものを使うけど、その上の関数は別のものにする

----------------------------------------
-- 型クラス まとめ

-- 型クラス定義
class Vector a where
    norm2 :: a -> Double
    dot :: a -> a -> Double
    norm2 x = dot x x
-- 型クラスのインスタンスである型の宣言
data Vect3 = Vect3 {v3x :: Int, v3y :: Int, v3z :: Int}
             deriving (Show)
instance Vector Vect3 where
    dot (Vect3 {v3x = x1, v3y = y1, v3z = z1}) (Vect3 {v3x = x2, v3y = y2, v3z = z2}) = realToFrac (x1 * x2 + y1*y2 + z1 * z2)


----------------------------------------
-- main
----------------------------------------
main = do
  cs <- getContents
  putStr $ numbering cs