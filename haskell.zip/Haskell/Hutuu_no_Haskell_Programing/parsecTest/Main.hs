module Main where

import MyParsec
import Text.ParserCombinators.Parsec

