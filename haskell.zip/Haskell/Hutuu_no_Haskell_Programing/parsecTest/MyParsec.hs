module MyParsec where
import Text.ParserCombinators.Parsec

-----------------------------------
-- HTML.hs
type HTML = [HTMLItem]

data HTMLItem = Text String | Param Href
        deriving (Show)

data Href = PageLink {hrefPageName :: String}
        deriving (Show)
a_href :: String -> String -> String
a_href url label =
         "<a href=\"" ++ escape url ++ "\">" ++ escape label ++ "</a>"

escape :: String -> String
escape = concatMap escapeChar

escapeChar :: Char -> String
escapeChar '<' = "&lt;"
escapeChar '>' = "&gt;"
escapeChar '&' = "&amp;"
escapeChar '"' = "&quot;"
escapeChar c = [c]


-----------------------------------
-- 文法の雰囲気
-- 一個一個の置き換え規則をパーサ(Parser型) で表す
-- <text> = <component>*
-- <component> = <wikiname>
--            | <urlAutoLink>
--            | <anyChar>
-- <wikiname> = ...
-- <urlAutoLink> = ...
-- <anyChar> = ...

-- Parser a のaは意味値?

-- 非終端文字<text> 一行
text :: Parser HTML
text = many component
  where
    component = do name <- try(wikiName)
                   return (Param $ PageLink name)
            <|> do url <- try(urlAutoLink)
                   return (Text $ a_href url url)
            <|> do c <- anyChar
                   return (Text $ escapeChar c)

-- 非終端文字<wikiName>
wikiName :: Parser String
wikiName = do w1 <- word
              w2 <- word
              ws <- many word
              return (concat (w1:w2:ws))
  where
    word = do c <- upper
              s <- many1 (lower <|> digit)
              return (c:s)

urlAutoLink :: Parser String
urlAutoLink = do a <- string "http"
                 b <- option "" (string "s") -- 正規表現の? 0 or 1的な？
                 c <- string "://"
                 d <- many1 urlChar
                 return $ concat [a,b,c,d]

urlChar :: Parser Char
urlChar = alphaNum
      <|> oneOf ";/?:@&=+$,-_.!~*'#%"  -- '(' ')'


--------
-- パーサを使ったwiki形式文字列一列のHTMLへのコンパイル
compileText :: String -> HTML
compileText str = case parse text "errFileName" str of
                    Right html -> html
                    Left err -> [Text (escape $ show err)]



