num = [1..]
fizz = cycle ["","","Fizz"]
buzz = cycle ["","","","","Buzz"]
fizzbuzzZip (x:xs) ("":fs) ("":bs) = show x : fizzbuzzZip xs fs bs
fizzbuzzZip (_:xs) (f:fs) (b:bs) = (f ++ b) : fizzbuzzZip xs fs bs
fizzbuzz n = take n $ fizzbuzzZip num fizz buzz

main = putStrLn.show $ fizzbuzz 30