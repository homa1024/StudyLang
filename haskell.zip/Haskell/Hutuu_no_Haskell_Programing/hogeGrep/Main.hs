module Main where
import Data.List
import Text.ParserCombinators.Parsec

(#) :: (a -> b) -> (b -> c) -> (a -> c)
f # g = g . f
infixl 2 #

(#>) :: a -> (a -> b) -> b
x #> f = f x
infixl 1 #>


grep ::  String -> [(Int, String)]
grep text = text #> lines #> zip [1..]